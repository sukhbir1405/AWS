const pkg = require("../source/node_modules/aws-cdk/package.json")
console.log(pkg.version)